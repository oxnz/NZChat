#-*- coding: utf-8 -*-
from NZQt import *

class NZStatus(QtCore.QObject):
	'''represent user status
	there's three so far, and only 2 usable
	'''
	ONLINE = QtCore.QString('在线')
#	INVISIBLE = QtCore.QString('隐身')
	OFFLINE = QtCore.QString('下线')
