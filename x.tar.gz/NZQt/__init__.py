
from PyQt4 import QtCore
from PyQt4 import QtGui
from PyQt4 import QtNetwork
#from PySide import QtCore
#from PySide import QtGui
#from PySide import QtNetwork

__all__ = ['QtCore', 'QtGui', 'QtNetwork']
