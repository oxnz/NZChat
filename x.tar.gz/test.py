#!/usr/bin/env python
#!/Applications/anaconda/bin/python

from NZChat import NZChat
from NZQt import *

#import socket
#client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
#client.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
#client.sendto('hello3', ('192.168.0.255', 8888))
#client.close()

#QtCore.Qt.QTextCodec.setCodecForLocale(QTextCodec.codecForName('utf8'))
#QTextCodec.setCodecForLocale(QTextCodec.codecForName('utf8'))
#QTextCodec.setCodecForTr(QTextCodec.codecForName('utf8'))

if __name__ == '__main__':
	import sys
	app = QtGui.QApplication(sys.argv)
	chat = NZChat()
	chat.show()
	sys.exit(app.exec_())
